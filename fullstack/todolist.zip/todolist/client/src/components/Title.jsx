import React from 'react'

const Title = () => {
    return (
        <div>
            <h1>Todo List</h1>
        </div>
    )
}

export default Title
